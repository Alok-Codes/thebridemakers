
	$(document).on('pageshow', function () {
		var elem = document.getElementById('mySwipe');
		window.mySwipe = Swipe(elem, {
		   startSlide: 1,
		   auto: 4000,
		   continuous: true,
		   disableScroll: true,
		   stopPropagation: true,
		   callback: function(index, element) {},
		   transitionEnd: function(index, element) {}
		});
		
		var hgt = $(window).height();
		$("div[data-role='page']").css("height", hgt);
	});		


function aboutus(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=aboutus", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#aboutus-visitor").html(response);
			$.mobile.changePage("#aboutus",  {transition:"slide"});
			$("#aboutus-visitor").trigger ("create");
		}
	});
}

function services(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=services", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#services-visitor").html(response);
			$.mobile.changePage("#services",  {transition:"slide"});
			$("#services-visitor").trigger ("create");
		}
	});
}

function whyus(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=whyus", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#whyus-visitor").html(response);
			$.mobile.changePage("#whyus",  {transition:"slide"});
			$("#whyus-visitor").trigger ("create");
		}
	});
}

function gallery(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=gallery", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#gallery-visitor").html(response);
			$.mobile.changePage("#gallery",  {transition:"slide"});
			$("#gallery-visitor").trigger ("create");
		}
	});
}

function contactus(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=contactus", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#contactus-visitor").html(response);
			$.mobile.changePage("#contactus",  {transition:"slide"});
			$("#contactus-visitor").trigger ("create");
		}
	});
}

function events(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=events", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#events-visitor").html(response);
			$.mobile.changePage("#events",  {transition:"slide"});
			$("#events-visitor").trigger ("create");
		}
	});
}

function newsletter(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=newsletter", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#newsletter-visitor").html(response);
			$.mobile.changePage("#newsletter",  {transition:"slide"});
			$("#newsletter-visitor").trigger ("create");
		}
	});
}

function appointment(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=appointment", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#appointment-visitor").html(response);
			$.mobile.changePage("#appointment",  {transition:"slide"});
			$("#appointment-visitor").trigger ("create");
		}
	});
}

function notes(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=notes", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#notes-visitor").html(response);
			$.mobile.changePage("#notes",  {transition:"slide"});
			$("#notes-visitor").trigger ("create");
		}
	});
}

function members(){	
	var id = 'visitor';
	var cid = 'thebridemakers';
	$.ajax({    
		type: "POST",
		url: "http://salon.apportunityonline.com/server/visitor_functions.php?p=members", 
		data: {id: id, cid: cid},            
		dataType: "html",
		beforeSend: function() {			
			$.mobile.loading('show'); // This will show ajax spinner
		},
		success: function(response){ 
			$.mobile.loading('hide'); // This will hide ajax spinner
			if(response == ""){response = '<center><img src="img/under_construction.gif" alt="Under Construction" id="under_construction"></center>'}
			$("#members-visitor").html(response);
			$.mobile.changePage("#members",  {transition:"slide"});
			$("#members-visitor").trigger ("create");
		}
	});
}

